<?php
namespace Firebase;

class ExpiredException extends \UnexpectedValueException
{
}
