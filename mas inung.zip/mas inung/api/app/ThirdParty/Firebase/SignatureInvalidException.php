<?php
namespace Firebase;

class SignatureInvalidException extends \UnexpectedValueException
{
}
