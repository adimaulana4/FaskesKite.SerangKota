<?php
namespace Firebase;

class BeforeValidException extends \UnexpectedValueException
{
}
