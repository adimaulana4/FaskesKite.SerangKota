<?php namespace App\Models;

use CodeIgniter\Model;
 
class RefJenisSaranaModel extends Model {

    protected $table = 'ref_jenis_sarana';
    protected $primaryKey = 'id';
    protected $returnType = 'object';
    protected $useSoftDeletes = false;

}