<?php namespace App\Models;

use CodeIgniter\Model;
 
class DataSaranaModel extends Model {

    protected $table = 'mst_sarana';
    protected $primaryKey = 'id';
    protected $returnType = 'object';
    protected $useSoftDeletes = false;

}