<?php namespace App\Controllers;

use \Firebase\JWT;
use CodeIgniter\Controller;

class Protect extends Controller
{
    public function __construct()
    {
        $this->auth = new Auth();
    }

    public function granted($authHeader){
        $secret_key = $this->auth->privateKey();
        $token = null;

        $arr = explode(" ", $authHeader);
        if(count($arr)<2){
            $token = null;
        }else{
            $token = $arr[1];
        }

        if($token){
            try {
                $decoded = JWT::decode($token, $secret_key, array('HS256'));
         
                // Access is granted. Add code of the operation here 
                if($decoded){
                    return true;
                }
            } catch (\Exception $e){
                return false;
            }
        }else{
            return false;
        }        
    }
}