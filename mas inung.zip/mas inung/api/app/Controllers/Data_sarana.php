<?php namespace App\Controllers;

use App\Controllers\Protect;
use CodeIgniter\RESTful\ResourceController;

header("Access-Control-Allow-Origin: * ");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

class Data_sarana extends ResourceController
{
	protected $format       = 'json';
	protected $modelName    = 'App\Models\DataSaranaModel';

	public function __construct()
    {
       $this->protect = new Protect();
	}
	
	public function index()
	{
		if($this->protect->granted($this->request->getServer('HTTP_AUTHORIZATION'))){
            $rows = $this->model->findAll(100,0);
            return $this->respond(['status'=>200, 'data'=>$rows], 200);
        }else{
            return $this->respond(['status'=>401, 'error'=>'akses ditolak'], 401);
        }
    }
    public function show($id=0)
	{
		if($this->protect->granted($this->request->getServer('HTTP_AUTHORIZATION'))){
            $rows = $this->model->find($id);
            return $this->respond(['status'=>200, 'data'=>$rows], 200);
        }else{
            return $this->respond(['status'=>401, 'error'=>'akses ditolak'], 401);
        }
	}

}
